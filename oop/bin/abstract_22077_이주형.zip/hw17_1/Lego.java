package hw17_1;

public class Lego extends Toy {
	public String toString() {
		return "Lego";
	}
}
