package hw17_1;

public class Robot extends Toy {
	public String toString() {
		return "Robot";
	}
}
