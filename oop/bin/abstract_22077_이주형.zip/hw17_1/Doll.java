package hw17_1;

public class Doll {
	public String toString() {
		return "Doll";
	}
}
