package hw17_1;

abstract public class Toy {
	
}
